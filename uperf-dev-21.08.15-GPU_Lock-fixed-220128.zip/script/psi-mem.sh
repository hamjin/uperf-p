#!/system/bin/sh
MODDIR=${0%/*}

/system/bin/resetprop --file $MODDIR/../common/system.prop
