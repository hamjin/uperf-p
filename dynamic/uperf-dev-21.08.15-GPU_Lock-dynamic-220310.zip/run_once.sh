BB=$BASEDIR/bin/busybox
$BB/busybox --install -s $BB 2>&1
