#!/system/bin/sh
# GPU Adjustment
# Author: HamJin @CoolApk
BASEDIR="$(dirname "$0")"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libcommon.sh
adj_log_path="$USER_PATH/log_adj.txt"
chmod 777 $BASEDIR/../bin/adjustment
sleeper() {
    sleep 10s
    change_task_rt "adjustment" "1"
    pin_proc_on_pwr "adjustment"
}
(sleeper &)
$BASEDIR/../bin/adjustment -l "$adj_log_path"

exit 0
