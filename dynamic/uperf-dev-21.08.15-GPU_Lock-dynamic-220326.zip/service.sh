#!/system/bin/sh
MODDIR=${0%/*}
#BootStrap Uperf
sh $MODDIR/initsvc_uperf.sh
