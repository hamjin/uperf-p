MODDIR=${0%/*}
SF=system/bin/surfaceflinger

# $1:file_node $2:owner $3:group $4:permission $5:secontext
__set_perm() {
    chown $2:$3 $1
    chmod $4 $1
    chcon $5 $1
}

if [ -f "$MODDIR/flag/need_recuser" ]; then
    rm -f $MODDIR/flag/need_recuser
    true >$MODDIR/disable
else
    true >$MODDIR/flag/need_recuser
fi

# maybe timing issue
sleep 3

rm -f $MODDIR/$SF
$MODDIR/system/bin/patchelf --add-needed libsfanalysis.so /$SF --output $MODDIR/$SF
__set_perm $MODDIR/$SF 0 0 0755 "$(ls -Zl /$SF | cut -d' ' -f5)"
