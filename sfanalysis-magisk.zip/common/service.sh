#!/system/bin/sh

BASEDIR="$(dirname $(readlink -f "$0"))"

wait_until_boot_complete() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done
}

crash_recuser() {
    wait_until_boot_complete
    rm -f $BASEDIR/flag/need_recuser
}

(crash_recuser &)
