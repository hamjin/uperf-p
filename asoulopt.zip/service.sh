MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    if [ -f "$p" ]; then
        chown root:root "$p"
        chmod 0666 "$p"
        echo "$1" >"$p"
        chmod 0444 "$p"
    fi
}

wait_until_login() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    # no need to start before the user unlocks the screen
    local test_file="/sdcard/Android/.ASOUL_PERMISSION_TEST"
    true > "$test_file"

    while [ ! -f "$test_file" ]; do
        true > "$test_file"
        sleep 1
    done

    rm "$test_file"
}

disable_userspace_boost() {
    # meme shit
    if [ -d /dev/migt ]; then
        chmod 0000 /dev/migt
        chmod 0000 /sys/module/migt/parameters/*
    fi

    # mtk shit
    lock_val "0" /sys/module/mtk_core_ctl/parameters/policy_enable
    lock_val "0" /sys/module/mtk_fpsgo/parameters/boost_affinity
    lock_val "0" /sys/module/fbt_cpu/parameters/boost_affinity
    lock_val "0" /sys/kernel/fpsgo/minitop/enable
}

if [ "$(getprop sys.boot_completed)" != "1" ]; then
    wait_until_login
    disable_userspace_boost
fi

killall -15 AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
