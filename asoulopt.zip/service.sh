MODDIR=${0%/*}
wait_until_login()
{
    # in case of /data encryption is disabled
    while [ $(getprop sys.boot_completed) != 1 ]; do
        sleep 1
    done

    # no need to start before the user unlocks the screen
    local test_file="/sdcard/Android/.ASOUL_PERMISSION_TEST"
    true > $test_file
    while [ ! -f $test_file ]; do
        true > $test_file
        sleep 1
    done
    rm "$test_file"
}

fuck_vendor_affinity()
{
    FBT_PATH="/sys/module/fbt_cpu/parameters/boost_affinity"
    if [ -f $FBT_PATH ]; then
        chown root:root $FBT_PATH
        chmod 0666 $FBT_PATH
        echo 0 > $FBT_PATH
        chmod 0444 $FBT_PATH
    fi

    FPSGO_PATH="/sys/module/mtk_fpsgo/parameters/boost_affinity"
    if [ -f $FPSGO_PATH ]; then
        chown root:root $FPSGO_PATH
        chmod 0666 $FPSGO_PATH
        echo 0 > $FPSGO_PATH
        chmod 0444 $FPSGO_PATH
    fi
}

wait_until_login
fuck_vendor_affinity
pkill AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
exit
