#!/system/bin/sh

BASEDIR="$(dirname $(readlink -f "$0"))"

crash_recuser() {
    rm $BASEDIR/logcat.log
    logcat -f $BASEDIR/logcat.log &
    sleep 60
    killall logcat
    rm -f $BASEDIR/flag/.need_recuser
}

(crash_recuser &)
