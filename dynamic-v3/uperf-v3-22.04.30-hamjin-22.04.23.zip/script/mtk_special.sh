#!/system/bin/sh
#
# Copyright (C) 2022 Ham Jin
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Runonce after boot, to speed up the transition of power modes in powercfg

# "Matt Yang(yc9559) is too lazy to copy and paste", said hellokf@github

BASEDIR="$(dirname $(readlink -f "$0"))"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libcommon.sh
. $BASEDIR/libpowercfg.sh
. $BASEDIR/libcgroup.sh
# EAS Fix for MTK, MT6893 and before
lock_val "1" /sys/devices/system/cpu/sched/hint_enable
chmod 004 /sys/devices/system/cpu/sched/hint_enable
lock_val "85" /sys/devices/system/cpu/sched/hint_load_thresh
chmod 004 /sys/devices/system/cpu/sched/hint_load_thresh
lock_val "2" /sys/devices/system/cpu/eas/enable
chmod 004 /sys/devices/system/cpu/eas/enable
# Enable CPU7 for MTK, MT6893 and before(need empty power_app_cfg.xml)
lock /sys/devices/system/cpu/sched/set_sched_isolation
for i in 0 1 2 3 4 5 6 7 8 9; do
    lock_val "0" $CPU/cpu$i/sched_load_boost
    lock_val "$i" /sys/devices/system/cpu/sched/set_sched_deisolation
done
# mi special
stop vendor.miperf
stop vendor.misys
stop vendor.misys@2.0
stop vendor.misys@3.0
stop thermald
stop getgameserver
#stop mi_thermald
# mi mcd always lock resolution and fps
killall fpsgo tcpdump-vendor
stop fpsgo
stop vendor_tcpdump
stop mcd_service
# MTK-EARA
stop eara-io
# MTK thermal-hal
stop vendor.thermal-hal-2-0.mtk
# MTK thermal-hal
#start vendor.thermal-hal-2-0.mtk
# stop mtk_core_ctl
lock_val "0" /sys/module/mtk_core_ctl/parameters/policy_enable
# Mediatek Thermal Driver
lock_val "0" /sys/class/thermal/thermal_message/balance_mode
chmod 444 /sys/devices/virtual/thermal/thermal_message/*
lock_val "1" /sys/kernel/thermal/sports_mode
# MTK FPSGO
## Useful Boost
lock_val "0" /sys/kernel/gbe/gbe_enable1
lock_val "0" /sys/kernel/gbe/gbe_enable2

lock_val "100" /sys/kernel/fpsgo/fbt/thrm_temp_th
lock_val "-1" /sys/kernel/fpsgo/fbt/thrm_limit_cpu
lock_val "-1" /sys/kernel/fpsgo/fbt/thrm_sub_cpu
lock_val "0" /sys/kernel/fpsgo/fbt/ultra_rescue
chmod 444 /sys/kernel/fpsgo/fbt/*

lock_val "0" /sys/kernel/fpsgo/common/fpsgo_enable
lock_val "0" /sys/kernel/fpsgo/common/force_onoff
lock_val "1" /sys/kernel/fpsgo/common/stop_boost
chmod 444 /sys/kernel/fpsgo/common/*

lock_val "1" /sys/module/mtk_fpsgo/parameters/adjust_loading
lock_val "0" /sys/module/mtk_fpsgo/parameters/cfp_onoff
lock_val "0" /sys/module/mtk_fpsgo/parameters/gcc_enable
lock_val "0" /sys/module/mtk_fpsgo/parameters/qr_enable
lock_val "0" /sys/module/mtk_fpsgo/parameters/start_limit
lock_val "1" /sys/module/mtk_fpsgo/parameters/fps_level_range
chmod 444 /sys/module/mtk_fpsgo/parameters/*

lock_val "1" /sys/kernel/fpsgo/fstb/adopt_low_fps
lock_val "125" /sys/kernel/fpsgo/fstb/fstb_fps_bypass_min
lock_val "0" /sys/kernel/fpsgo/fstb/fstb_self_ctrl_fps_enable
lock_val "1 125-123" /sys/kernel/fpsgo/fstb/fstb_soft_level
lock_val "0" /sys/kernel/fpsgo/fstb/set_renderer_no_ctrl
lock_val "125" /sys/kernel/fpsgo/fstb/set_renderer_max_fps
lock_val "1" /sys/kernel/fpsgo/fstb/tfps_to_powerhal_enable
#lock_val "com.tencent.tmgp.sgame 0 1 120-120" /sys/kernel/fpsgo/fstb/fstb_fps_list
#lock_val "com.miHoYo.Yuanshen 0 2 120-120 60-60" /sys/kernel/fpsgo/fstb/fstb_fps_list
#lock_val "com.tencent.tmgp.sgame 0 1 120-120" /sys/kernel/fpsgo/fstb/fstb_fps_list
chmod 444 /sys/kernel/fpsgo/fstb/*

# Disable automatic voltage increase by MTK
lock_val "disable" /proc/gpufreqv2/aging_mode
lock_val "disable" /proc/gpufreqv2/gpm_mode
lock_val "disable" /proc/gpufreq/aging_mode

# Fix gpu always boost in MT6983 and MT6895, f**K buggy MTK kernel drivers.
#lock_val "0" /sys/kernel/ged/hal/dcs_mode

# MemLatency Fix For Mediatek, f**k the whitelist
## 6983&6895
lock_val "cm_mgr_disable_fb 0" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_cpu_map_dram_enable 0" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_perf_force_enable 1" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_perf_enable 1" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "dsu_enable 0" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_enable 1" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_ipi_enable 1" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_dram_level 8" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_emi_demand_check 0" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "dsu_opp_send 0" /sys/kernel/cm_mgr/dbg_cm_mgr
lock_val "dsu_mode_change 1" /sys/kernel/cm_mgr/dbg_cm_mgr
##6893 and before?
lock_val "cm_mgr_disable_fb 0" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_cpu_map_dram_enable 0" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_perf_force_enable 1" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_perf_enable 1" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_opp_enable 1" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_enable 1" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_sspm_enable 0" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_ipi_enable 1" /proc/cm_mgr/dbg_cm_mgr
lock_val "cm_mgr_dram_level 6" /proc/cm_mgr/dbg_cm_mgr

# yes, let it respawn
killall fpsgo tcpdump-vendor
killall mi_thermald
killall thermald
