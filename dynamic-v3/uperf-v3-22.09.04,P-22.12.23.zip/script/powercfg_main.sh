#!/system/bin/sh
#
# Copyright (C) 2021-2022 Matt Yang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

BASEDIR="$(dirname $(readlink -f "$0"))"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libcommon.sh
. $BASEDIR/libsysinfo.sh
action="$1"
sleep 2s
if [ ! -f "/dev/asopt_game" ]; then
    IS_GAME="0"
else
    IS_GAME="$(cat /dev/asopt_game)"
fi
HAS_GAME="$(grep -E "gbalance" <"$USER_PATH"/uperf.json)"

if [ "$IS_GAME" == "1" ] && [ "$HAS_GAME" != "" ]; then
    action="g$action"
fi

case "$action" in
"powersave" | "balance" | "performance" | "fast") echo "$action" >"$USER_PATH"/cur_powermode.txt ;;
"gpowersave" | "gbalance" | "gperformance" | "gfast") echo "$action" >"$USER_PATH"/cur_powermode.txt ;; #game mode
"init") echo "auto" >"$USER_PATH/cur_powermode.txt" ;;                                             #default auto
"pedestal")
    if [ "$(grep -E "pedestal" <"$USER_PATH"/uperf.json)" != "" ]; then
        echo "pedestal" >"$USER_PATH"/cur_powermode.txt
    else
        echo "performance" >"$USER_PATH"/cur_powermode.txt
    fi
    ;;
*)
    echo "Failed to apply unknown action '$1'. Reset current mode to 'auto'."
    echo "auto" >"$USER_PATH/cur_powermode.txt" #default auto
    ;;
esac
