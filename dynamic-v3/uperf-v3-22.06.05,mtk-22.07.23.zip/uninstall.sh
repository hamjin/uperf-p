rm -rf /sdcard/yc/uperf/ /data/adb/*/uperf
chmod 666 /data/powercfg*
rm -rf /data/powercfg*
rm -rf /sdcard/yc/uperf
rm -rf /sdcard/Android/yc
